const wordList = [
  {
    word: "black",
    hint: "Most Sexy Dress on You"
  },
  {
    word: "saree",
    hint:"Whenever you wear my heart beats faster"
},

{ 
    word: "love",
    hint: "I _____ you the most."
},

{
    word: "hot",
    hint: "You sweat because you are"
},

{ 
     word:"teddy",
     hint:"In future, our bed will be full of"
},

{
    word:"cute",
    hint:" no one is as ___ as you"
},

{ 
    word:"forever",
    hint :" Be mine ___"
},

];


