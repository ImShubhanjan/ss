INSERT INTO MyUser (userid,username,password) VALUES ('1','Adrish','$2a$10$/nO4/5ZJHq4QtSMto0ODqekvgomt8B2mSJ1Lh8IjTZZBaBtnwLFq6'), 
('2','Praveen','$2a$10$2udiuD6pRTI35KryRaP5YulpFT9h/CExpUhY43fBHV.NVEZudo0m.'),
('3','Nitu','$2a$10$4a1kRumFknmsd.g.LBDdXeOlzGNcJklzZB6V3TevOLt.slp3sYec2'), 
('4','Riya','$2a$10$ob/xvYjBbuIOUGvBcYWwbeLmLHYVv.a9Lq29WynVhTbTFiAA62YCa');