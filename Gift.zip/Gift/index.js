const express = require("express");
const app = express();
const path = require("path");

const staticPath = path.join(__dirname);
const viewsPath = path.join(__dirname + "/templates/views");

app.set("views", viewsPath);
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(express.static(staticPath));

app.get("/", (req, res) => {
  res.render("first");
});

app.get("/start", (req, res) => {
  const names = ["Queen", "Teddy", "Hottie", "Sexy"];
  res.render("start", { names: names });
});

app.get("/fireworks", (req, res) => {
  res.render("fireworks");
});

app.get("/special", (req, res) => {
  res.render("special");
});

app.get("/game", (req, res) => {
  res.render("game");
});

app.get("/again", (req, res) => {
  res.render("again");
});

app.get("/link", (req, res) => {
  res.render("link");
});

app.get("/password", (req, res) => {
  res.render("password");
});

app.post("/password", (req, res) => {
  const password = req.body.password;
  if (password === "Misti") {
    res.render("fireworks");
  } else {
    res.render("password");
  }
});

app.get("/stop", (req,res) => {
  res.render("stop");
});

// app.get("/first", (req, res) => {
//   res.render("first");
// })
app.listen(process.env.PORT || 5000, () => {
  console.log("Server started at Port 5000");
});
