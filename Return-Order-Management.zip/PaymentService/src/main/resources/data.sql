insert into CREDIT_CARD values (1234567,50000);
insert into CREDIT_CARD values (1234569,50000);
insert into CREDIT_CARD values (1234568,00);
insert into CREDIT_CARD values (1234570,60000);