const wordList = [
  {
    word: "black",
    hint: "Most Sexy Dress on You"
  },
  {
    word: "saree",
    hint:"Whenever you wear my heart beats faster"
},

{ 
    word: "love",
    hint: "I _____ you the most."
},

{
    word: "hot",
    hint: "You sweat because you are"
},

{ 
     word:"teddy",
     hint:"In future, our bed will be full of"
},

{
    word:"cute",
    hint:" no one is as ___ as you"
},

{ 
    word:"forever",
    hint :" Be mine ___"
},
{ 
    word:"riya",
    hint :" what is the capital of my heart?"
},
{ 
    word:"roses",
    hint :"which flower petals will be on our bed?"
},
{ 
    word:"blue",
    hint :"Our favorite color"
},
{ 
    word:"fultosi",
    hint :"whenever I annoy you, you become"
},
{ 
    word:"maldives",
    hint :"honeymoon destination"
},
{ 
    word:"rosy",
    hint :"you are more beautiful than rose, so I call you"
},
{ 
    word:"valentine",
    hint :"You are my 14th Feb"
},
{ 
    word:"life",
    hint :"you are my _____ partner"
},
{ 
    word:"yes",
    hint :"Are we married?"
},

];


