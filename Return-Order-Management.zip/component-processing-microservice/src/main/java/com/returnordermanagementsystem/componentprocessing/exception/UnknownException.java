package com.returnordermanagementsystem.componentprocessing.exception;

public class UnknownException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public UnknownException(String message) {
		super(message);
	}
}
