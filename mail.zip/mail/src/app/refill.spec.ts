import { Refill } from './refill';

describe('Refill', () => {
  it('should create an instance', () => {
    expect(new Refill()).toBeTruthy();
  });
});
