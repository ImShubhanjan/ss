import { DrugLocationDetails } from './drug-location-details';

describe('DrugLocationDetails', () => {
  it('should create an instance', () => {
    expect(new DrugLocationDetails()).toBeTruthy();
  });
});
